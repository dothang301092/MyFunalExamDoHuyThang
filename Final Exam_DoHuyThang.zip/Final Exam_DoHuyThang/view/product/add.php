<div class="container" >
    <div class="row">
        <div class="col-12 col-12">
            <form action="" method="post">
                <div class="form-group">
                    <label for="">Product Name</label>
                    <input type="text" name="product_name" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Type</label>
                    <input type="text" name="product_type" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Price</label>
                    <input type="text" name="product_price" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Quantity</label>
                    <input type="text" name="product_quantity" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Description</label>
                    <input type="text" name="product_desc" class="form-control">
                </div>
                <input type="submit" value="Add">
            </form>
        </div>
    </div>
</div>

